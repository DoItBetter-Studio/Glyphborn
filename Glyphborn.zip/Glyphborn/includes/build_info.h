// Auto-generated build info
#pragma once
#define BUILD_VERSION        "0.0.0"
#define BUILD_REVISION       "3"
#define BUILD_FULL_VERSION   "0.0.0.3"
#define BUILD_PLATFORM       ""
#define BUILD_DISTRO         ""
#define BUILD_TIMESTAMP      "2025-12-01 19:37:36"
