#ifndef TEST_CUBE_H
#define TEST_CUBE_H

#include <maths/vec3.h>

extern Vec3 cube_vertices[8];
extern int cube_edges[12][2];

#endif // !TEST_CUBE_H
